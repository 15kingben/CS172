Ben King
bking11@u.rochester.edu
No Partner

In this Lab I implemented a Heap data structure using a partially sorted binary tree. The Heap uses a generic array to store the data and dynamically resizes if the data gets too big. It can also be constructed from an array using heapify which is O(N). 