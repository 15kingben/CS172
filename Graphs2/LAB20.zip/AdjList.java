//@author Ben King
interface AdjList {
	int begin();
	int next();
	boolean end();
}
