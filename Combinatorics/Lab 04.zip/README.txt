Ben King
bking11@u.rochester.edu
no partner

In this lab I created methods which implement several Combinatorics formulas in a class Called Combinatorics, the main method of which tests these methods.