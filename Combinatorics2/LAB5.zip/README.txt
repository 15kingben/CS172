Ben King
bking11@u.rochester.edu
No Partner

In this lab I implemented more complex combinatorics formulas in Java. I pasted in the combinatorics formulas like permutations and combinations from the previous lab and used them in the more complex formulas. The Lab contains one Java class called Combinatorics2 which contains a main tester method and methods to answer all the questions.