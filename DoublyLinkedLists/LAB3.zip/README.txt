Ben King
bking11@u.rochester.edu
no partner

In this lab I implemented a doubly-linked list using java generics. I implemented the same methods as the singly-linked list like insert and print, as well as printReverse(), which was easier to implement than in a singly-linked version. In this implementation, I also used two dummy head and tail nodes, which ended up being less code to write. The source files are MyDoubleNode, the node class; DoublyLinkedList, the given interface; MyDoblyLinkedList, my implementation of DoublyLinkedList; and Tester, which tests the LinkedList class.