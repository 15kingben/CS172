Ben King
bking11@u.rochester.edu
no partner

	In this lab I created an implementation of the queue data structure using the
code for the doublylinkedlist that I created in a previous lab. The zip conatins the queue interface, a MyQueue class, and a tester class which does several enqueues and dequeues. It also contains classes copied from the previous doubly-linked list lab. 