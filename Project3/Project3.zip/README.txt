Ben King
bking11@u.rochester.edu
No partner

In this lab I created a program to play a word search of arbitrary size given a list of words. I did this by using the hash table that I made for Lab 16 to store the dictionary of words. I also used quicksort from Weiss to sort my output. There are two files: MyHashTable, which was from the lab, and WordSearch, which is the project. WordSearch takes the files for the dictionary, input, and output as directed by the specification. 