Ben King
bking11@u.rochester.edu
No Partner

In this lab I compared several sorting algorithms by analyzing their runtimes and numbers of comparisons, and plotting that data as a trend as the input size n increased. While the time did not offer reliable data, the # of comparisons data offered reliable regressions which correctly modeled the expected Big O's of the Algorithms. There is one java file, SortTest, which includes all the code including QuickSort which I implemented for extra credit. QuickSort ran in O(nlogn) time and was faster than the java sort method overall. The zip also includes an excel file and PDF of that file which has the graphs and the data. 