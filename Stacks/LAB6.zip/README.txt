Ben King
bking11@u.rochester.edu
no partner

In this lab I implemented a stack interface(MyStack) which is based on the singly linked list that I made for a previous lab. There is also a tester class which tests all the methods of the stack class. The zip also contains all the files for linkedlist from the previous lab.