//@author Ben King
//taken from lab
public interface SimpleLinkedList <AnyType> {
	public void insert(AnyType x);
	public void delete(AnyType x);
	public boolean lookup(AnyType x);//edit from lab
	public boolean isEmpty();
	public void printList();
}
