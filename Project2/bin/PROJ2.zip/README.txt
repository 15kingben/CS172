Ben King
bking11@u.rochester.edu
No Partner


My Program works by taking lines of a file as input, deleting all spaces in the lines, and parsing in Doubles and Operators into the postfix queue using Shunting Yard. It then solves the expressions and writes them to a file. The hardest parts were parsing and File I/O because java is ludicrous when it comes to files. 

I implemented % and trig functions so I think I should get extra credit for that. 

The main class is Calculator.java which takes 2 args for input and output files. The zip also includes the classes for Stacks and Queues from the previous Labs.