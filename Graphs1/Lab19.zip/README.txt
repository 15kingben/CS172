Ben King
bking11@u.rochester.edu

No Partner

In this lab I implemented directed and undirected graphs, and made an iterator to print through the list of connections. Graphs.java contains the graph class and a tester method, AdjList, is the interface of the iterator, and Edge is a class that represents and edge.