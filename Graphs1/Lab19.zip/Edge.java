// Of course, we need an edge class
public class Edge {
	public final int v, w; // an edge from v to w

	public Edge(int v, int w) { 
		this.v = v;
		this.w = w;
	}
	
}