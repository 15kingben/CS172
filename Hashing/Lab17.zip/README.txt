Ben King
bking11@u.rochester.edu
No Partner

In this Lab I implemented a hash table with linear probing and dynamic resizing which checks for duplicate words upon insertion. The formula for hashing that I used was from Weiss. I then hashed 10 paragraphs of sample text into the table to test its capabilities. The single class file is MyHashTable.java which has a main method to take the input and run the program. The input file is called input.txt.